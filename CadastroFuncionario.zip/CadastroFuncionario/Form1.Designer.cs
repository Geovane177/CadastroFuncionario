﻿namespace Cadastro_funcionario
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            textBox1 = new TextBox();
            dataGridView1 = new DataGridView();
            btn_salvar = new Button();
            btn_editar = new Button();
            btn_excluir = new Button();
            label2 = new Label();
            txt_id = new TextBox();
            label3 = new Label();
            txt_nome = new TextBox();
            label4 = new Label();
            txt_cpf = new MaskedTextBox();
            txt_cargo = new TextBox();
            cmb_setor = new ComboBox();
            label5 = new Label();
            label6 = new Label();
            label7 = new Label();
            label8 = new Label();
            txt_salario = new TextBox();
            groupBox1 = new GroupBox();
            rB_feminino = new RadioButton();
            rB_masculino = new RadioButton();
            txt_data = new DateTimePicker();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
            groupBox1.SuspendLayout();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(96, 47);
            label1.Margin = new Padding(4, 0, 4, 0);
            label1.Name = "label1";
            label1.Size = new Size(251, 25);
            label1.TabIndex = 0;
            label1.Text = "Digite o nome do funcionario:";
            // 
            // textBox1
            // 
            textBox1.Location = new Point(357, 42);
            textBox1.Margin = new Padding(4, 5, 4, 5);
            textBox1.Name = "textBox1";
            textBox1.Size = new Size(617, 31);
            textBox1.TabIndex = 1;
            // 
            // dataGridView1
            // 
            dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView1.Location = new Point(96, 127);
            dataGridView1.Margin = new Padding(4, 5, 4, 5);
            dataGridView1.Name = "dataGridView1";
            dataGridView1.RowHeadersWidth = 62;
            dataGridView1.Size = new Size(880, 300);
            dataGridView1.TabIndex = 14;
            // 
            // btn_salvar
            // 
            btn_salvar.Location = new Point(249, 807);
            btn_salvar.Margin = new Padding(4, 5, 4, 5);
            btn_salvar.Name = "btn_salvar";
            btn_salvar.Size = new Size(107, 38);
            btn_salvar.TabIndex = 11;
            btn_salvar.Text = "Salvar";
            btn_salvar.UseVisualStyleBackColor = true;
            btn_salvar.Click += btn_salvar_Click;
            // 
            // btn_editar
            // 
            btn_editar.Location = new Point(480, 807);
            btn_editar.Margin = new Padding(4, 5, 4, 5);
            btn_editar.Name = "btn_editar";
            btn_editar.Size = new Size(107, 38);
            btn_editar.TabIndex = 12;
            btn_editar.Text = "Editar";
            btn_editar.UseVisualStyleBackColor = true;
            // 
            // btn_excluir
            // 
            btn_excluir.Location = new Point(709, 807);
            btn_excluir.Margin = new Padding(4, 5, 4, 5);
            btn_excluir.Name = "btn_excluir";
            btn_excluir.Size = new Size(107, 38);
            btn_excluir.TabIndex = 13;
            btn_excluir.Text = "Excluir";
            btn_excluir.UseVisualStyleBackColor = true;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(97, 457);
            label2.Margin = new Padding(4, 0, 4, 0);
            label2.Name = "label2";
            label2.Size = new Size(34, 25);
            label2.TabIndex = 6;
            label2.Text = "ID:";
            // 
            // txt_id
            // 
            txt_id.Location = new Point(186, 452);
            txt_id.Margin = new Padding(4, 5, 4, 5);
            txt_id.Name = "txt_id";
            txt_id.ReadOnly = true;
            txt_id.Size = new Size(141, 31);
            txt_id.TabIndex = 2;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(97, 512);
            label3.Margin = new Padding(4, 0, 4, 0);
            label3.Name = "label3";
            label3.Size = new Size(65, 25);
            label3.TabIndex = 8;
            label3.Text = "Nome:";
            // 
            // txt_nome
            // 
            txt_nome.Location = new Point(186, 507);
            txt_nome.Margin = new Padding(4, 5, 4, 5);
            txt_nome.Name = "txt_nome";
            txt_nome.Size = new Size(413, 31);
            txt_nome.TabIndex = 3;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(647, 512);
            label4.Margin = new Padding(4, 0, 4, 0);
            label4.Name = "label4";
            label4.Size = new Size(46, 25);
            label4.TabIndex = 10;
            label4.Text = "CPF:";
            // 
            // txt_cpf
            // 
            txt_cpf.Location = new Point(709, 507);
            txt_cpf.Margin = new Padding(4, 5, 4, 5);
            txt_cpf.Mask = "000.000.000-00";
            txt_cpf.Name = "txt_cpf";
            txt_cpf.Size = new Size(211, 31);
            txt_cpf.TabIndex = 4;
            // 
            // txt_cargo
            // 
            txt_cargo.Location = new Point(457, 572);
            txt_cargo.Margin = new Padding(4, 5, 4, 5);
            txt_cargo.Name = "txt_cargo";
            txt_cargo.Size = new Size(141, 31);
            txt_cargo.TabIndex = 6;
            // 
            // cmb_setor
            // 
            cmb_setor.DisplayMember = "TI";
            cmb_setor.FormattingEnabled = true;
            cmb_setor.Items.AddRange(new object[] { "TI", "Atendimento", "Administração" });
            cmb_setor.Location = new Point(709, 572);
            cmb_setor.Margin = new Padding(4, 5, 4, 5);
            cmb_setor.Name = "cmb_setor";
            cmb_setor.Size = new Size(211, 33);
            cmb_setor.TabIndex = 7;
            cmb_setor.ValueMember = "TI";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(97, 577);
            label5.Margin = new Padding(4, 0, 4, 0);
            label5.Name = "label5";
            label5.Size = new Size(53, 25);
            label5.TabIndex = 15;
            label5.Text = "Data:";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new Point(377, 577);
            label6.Margin = new Padding(4, 0, 4, 0);
            label6.Name = "label6";
            label6.Size = new Size(64, 25);
            label6.TabIndex = 16;
            label6.Text = "Cargo:";
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Location = new Point(636, 577);
            label7.Margin = new Padding(4, 0, 4, 0);
            label7.Name = "label7";
            label7.Size = new Size(58, 25);
            label7.TabIndex = 17;
            label7.Text = "Setor:";
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Location = new Point(97, 642);
            label8.Margin = new Padding(4, 0, 4, 0);
            label8.Name = "label8";
            label8.Size = new Size(69, 25);
            label8.TabIndex = 18;
            label8.Text = "Salario:";
            // 
            // txt_salario
            // 
            txt_salario.Location = new Point(186, 637);
            txt_salario.Margin = new Padding(4, 5, 4, 5);
            txt_salario.Name = "txt_salario";
            txt_salario.Size = new Size(141, 31);
            txt_salario.TabIndex = 8;
            // 
            // groupBox1
            // 
            groupBox1.Controls.Add(rB_feminino);
            groupBox1.Controls.Add(rB_masculino);
            groupBox1.Location = new Point(97, 685);
            groupBox1.Margin = new Padding(4, 5, 4, 5);
            groupBox1.Name = "groupBox1";
            groupBox1.Padding = new Padding(4, 5, 4, 5);
            groupBox1.Size = new Size(276, 85);
            groupBox1.TabIndex = 20;
            groupBox1.TabStop = false;
            groupBox1.Text = "Sexo:";
            // 
            // rB_feminino
            // 
            rB_feminino.AutoSize = true;
            rB_feminino.Location = new Point(151, 35);
            rB_feminino.Margin = new Padding(4, 5, 4, 5);
            rB_feminino.Name = "rB_feminino";
            rB_feminino.Size = new Size(110, 29);
            rB_feminino.TabIndex = 10;
            rB_feminino.TabStop = true;
            rB_feminino.Text = "Feminino";
            rB_feminino.UseVisualStyleBackColor = true;
            // 
            // rB_masculino
            // 
            rB_masculino.AutoSize = true;
            rB_masculino.Location = new Point(9, 35);
            rB_masculino.Margin = new Padding(4, 5, 4, 5);
            rB_masculino.Name = "rB_masculino";
            rB_masculino.Size = new Size(117, 29);
            rB_masculino.TabIndex = 9;
            rB_masculino.TabStop = true;
            rB_masculino.Text = "Masculino";
            rB_masculino.UseVisualStyleBackColor = true;
            // 
            // txt_data
            // 
            txt_data.CustomFormat = "dd/MM/yyyy";
            txt_data.Format = DateTimePickerFormat.Custom;
            txt_data.Location = new Point(186, 572);
            txt_data.Margin = new Padding(4, 5, 4, 5);
            txt_data.Name = "txt_data";
            txt_data.Size = new Size(141, 31);
            txt_data.TabIndex = 5;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1076, 893);
            Controls.Add(txt_data);
            Controls.Add(groupBox1);
            Controls.Add(txt_salario);
            Controls.Add(label8);
            Controls.Add(label7);
            Controls.Add(label6);
            Controls.Add(label5);
            Controls.Add(cmb_setor);
            Controls.Add(txt_cargo);
            Controls.Add(txt_cpf);
            Controls.Add(label4);
            Controls.Add(txt_nome);
            Controls.Add(label3);
            Controls.Add(txt_id);
            Controls.Add(label2);
            Controls.Add(btn_excluir);
            Controls.Add(btn_editar);
            Controls.Add(btn_salvar);
            Controls.Add(dataGridView1);
            Controls.Add(textBox1);
            Controls.Add(label1);
            Margin = new Padding(4, 5, 4, 5);
            Name = "Form1";
            Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
            groupBox1.ResumeLayout(false);
            groupBox1.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private TextBox textBox1;
        private DataGridView dataGridView1;
        private Button btn_salvar;
        private Button btn_editar;
        private Button btn_excluir;
        private Label label2;
        private TextBox txt_id;
        private Label label3;
        private TextBox txt_nome;
        private Label label4;
        private MaskedTextBox txt_cpf;
        private TextBox txt_cargo;
        private ComboBox cmb_setor;
        private Label label5;
        private Label label6;
        private Label label7;
        private Label label8;
        private TextBox txt_salario;
        private GroupBox groupBox1;
        private DateTimePicker txt_data;
        private RadioButton rB_feminino;
        private RadioButton rB_masculino;
    }
}
