namespace Cadastro_funcionario
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        public string sexo_var;

        public void Verifica_sexo()
        {
            if (rB_masculino.Checked)
            {
                sexo_var = "Masculino";
            }
            else if (rB_feminino.Checked)
            {
                sexo_var = "Feminino";
            }
            else
            {
                sexo_var = "";
            }
        }


        private void btn_salvar_Click(object sender, EventArgs e)
        {
            Verifica_sexo();
            try
            {
                if (!txt_nome.Text.Equals("") && !txt_cpf.Text.Equals("") && !txt_cargo.Text.Equals("") && !cmb_setor.Items.Equals("") && sexo_var != "" && !txt_data.Text.Equals("") && !txt_salario.Text.Equals(""))
                {

                    DateTime dataConvertida = DateTime.Parse(txt_data.Text);
                    decimal valorDecimal = decimal.Parse(txt_salario.Text);

                    Funcionarios funciona = new Funcionarios();
                    funciona.Nome = txt_nome.Text;
                    funciona.Cpf = txt_cpf.Text;
                    funciona.Cargo = txt_cargo.Text;
                    funciona.Setor = cmb_setor.Text;
                    funciona.Sexo = sexo_var;
                    funciona.DataNascimento = dataConvertida;
                    funciona.Salario = valorDecimal;

                    if (funciona.CadastrarFunc())
                    {
                        MessageBox.Show("cadastro realizado");
                        txt_nome.Clear();
                        txt_cpf.Clear();
                        txt_cargo.Clear();
                        txt_salario.Clear();
                    }
                    else
                    {
                        MessageBox.Show("erro 1 else");
                    }

                }
                else
                {
                    MessageBox.Show("preencha os campos corretamente, erro else 2");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erro ao cadastrar esse funcionario erro no catch do forms", ex.Message);
            }
        }


    }
}
