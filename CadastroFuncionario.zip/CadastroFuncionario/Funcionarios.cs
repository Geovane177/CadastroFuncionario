﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cadastro_funcionario
{
    class Funcionarios
    {
        private int id;
        private string nome;
        private string cpf;
        private DateTime dataNascimento;
        private string cargo;
        private string setor;
        private decimal salario;
        private string sexo;

        public int Id
        {
            get { return id; }
            set { id = value; }
        }
        public string Nome
        {
            get { return nome; }
            set { nome = value; }
        }
        public string Cpf
        {
            get { return cpf; }
            set { cpf = value; }
        }
        public DateTime DataNascimento
        {
            get { return dataNascimento; }
            set { dataNascimento = value; }
        }
        public string Cargo
        {
            get { return cargo; }
            set { cargo = value; }
        }
        public string Setor
        {
            get { return setor; }
            set { setor = value; }
        }
        public decimal Salario
        {
            get { return salario; }
            set { salario = value; }

        }
        public string Sexo
        {
            get { return sexo; }
            set { sexo = value; }
        }

        public bool CadastrarFunc()
        {
            try
            {
                using (MySqlConnection conexaoBanco = new BancoDB().Conectar())
                {

                    string inserir = "insert into funciona (nome, cpf, dataNascimento, cargo, setor, salario, sexo) values (@nome, @cpf, @dataNascimento, @cargo, @setor, @salario, @sexo);";

                    MySqlCommand comando = new MySqlCommand(inserir, conexaoBanco);
                    comando.Parameters.AddWithValue("@nome", Nome);
                    comando.Parameters.AddWithValue("@cpf", Cpf);
                    comando.Parameters.AddWithValue("@dataNascimento", DataNascimento.ToString("yyyy-MM-dd"));
                    comando.Parameters.AddWithValue("@cargo", Cargo);
                    comando.Parameters.AddWithValue("@setor", Setor);
                    comando.Parameters.AddWithValue("@salario", Salario);
                    comando.Parameters.AddWithValue("@sexo", Sexo);

                    int resultado = comando.ExecuteNonQuery();

                    if (resultado > 0)
                    {
                        return true;
                    }
                    else
                    {
                        return false;
                    }
                    
                }
            }
            catch(Exception ex)
            {
                MessageBox.Show("Erro ao cadastrar, erro no catch do funcionarios" + ex.Message);
                return false;
            }
        }

       
    }
}
